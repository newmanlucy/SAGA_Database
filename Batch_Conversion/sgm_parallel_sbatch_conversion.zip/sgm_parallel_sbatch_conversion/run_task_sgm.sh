#!/bin/bash
#take the line indicated as the input parameter
#input_list.txt has the name of all the files to be processed
file=`sed -n "$1 p" sgm_videofiles.txt`

# command options $file

ffmpeg -i $file -f mp4 -c:v libx264 -c:a copy -crf 17 "$file.h264.mp4"

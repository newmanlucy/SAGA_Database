import os
import csv
import ftfy 
import re
import itertools
import sys


###############################################################################

##             directories and file lists for testing purposes               ##

###############################################################################

## if we want to search through a directory
current_dir = "/project/sgsg/lab/archives/Spontaneous Sign Systems/0Test/Parse_CSV"
Turkey_dir = "/project/sgsg/lab/archives/Spontaneous Sign Systems/Turkey/Coding"
Taiwan_dir = "/project/sgsg/lab/archives/Spontaneous Sign Systems/Taiwan/Coding"
archive_root = "/project/sgsg/lab/archives/Spontaneous Sign Systems"

## for testing a list of files 
file_list = ["./test_files/4 gesture description_1_a.code g2.csv",
    "./test_files/4 gesture description_2_b.g-sp list.csv",
    "./test_files/4 gesture description_3_2 all fields.csv",
    "./test_files/4 gesture description_4_a.code g-sp.csv",
    "./test_files/4 gesture description_5_c.create utts.csv",
    "./test_files/4 gesture description_6_d.questions.csv",
    "./test_files/4 gesture description_7_f.all fields.csv",
    "./test_files/4 gesture description_8_Layout #8.csv"
    ]

seven_files = file_list[:7]

###############################################################################

##      get sets of CSVs and check whether exports have been completed       ##

###############################################################################


## set of CSV files resuting from a single fmp export
class FilemakerExport:
    def __init__(self, name, root, fmp_file, layouts):
        self.name = name
        self.root = root
        self.layouts = layouts
        self.fmp_file = fmp_file
    def add_layout(self, layout):
        self.layouts.append(layout)
    def equal(self, name, root):
        if self.name == name and self.root == root:
            return True
        else:
            return False

## gets lists of csvs resulting from an fmp export. relies on fmp files being
## in the same directory and using the naming conventions resulting from the 
## export process described in instructions.txt
def get_fmp_exports(rootdir):
    exports = set()
    num_csv = 0
    num_found = 0
    for root, subdirs, files in os.walk(rootdir):
        for file in files:
            name, ext = os.path.splitext(file)
            if ext in [".fp7", ".fmp12"] and name[0] != ".":
                full_path = os.path.join(root, file)
                fmp_export = FilemakerExport(name, root, full_path, [])
                exports.add(fmp_export)
            if ext == ".csv" and name[0] != ".":
                num_csv += 1
                for fmp_file in exports:
                    if fmp_file.name in name and fmp_file.root == root:
                        full_path = os.path.join(root, file)
                        fmp_file.add_layout(full_path)
                        num_found += 1
                        break
    
    return exports


## check how many excel files have a csv with the same name
## returns list of excel files with no csv
def check_csv_exports(rootdir):
    no_csv = set()
    num_excel = 0
    num_csv = 0
    for root, subdirs, files in os.walk(rootdir):
        for file in files:
            name, ext = os.path.splitext(file)
            if ext in [".xls", ".xlsx", ".xlsm"] and name[0] != ".":
                num_excel += 1
                full_path = os.path.join(root, file)
                csv_file = os.path.join(root, name + ".csv")
                if os.path.isfile(csv_file):
                    num_csv += 1
                else:
                    no_csv.add(full_path)
    print(str(num_csv) + " of " + str(num_excel) + " excel files have csv")
    return no_csv



###############################################################################

##                       Reading the CSV files                               ##

###############################################################################


## get all the unique column headers in a list of files
def get_columns(file_list):
    columns = set()
    for file in file_list:
        with open(file, encoding="cp437") as csv_file:
            csv_reader = csv.reader(csv_file)
            header = next(csv_reader)
            for col in header:
                columns.add(col)
    return columns


## get a dictionary of all the headers connected to a list
## of the files that contain those headers:
##    { col_hdr1: [file1, file3, file4,...], 
##      col_hdr2: [file2, file6, ....],
##    ... , col_hdrn: [file1, file5, file7] }
def get_files_with_header(file_list):
    files_with_header = {}
    for file in file_list:
        with open(file, newline='\n', encoding="cp437") as csv_file:
            csv_reader = csv.reader(csv_file)
            header = next(csv_reader)
            for col in header:
                if col in files_with_header:
                    files_with_header[col].append(file)
                else: 
                    files_with_header[col] = [file]
    return files_with_header

## get number of non-blank rows in a dictionary with the following format:
##    { col_hdr1: { file1: num_nonblank1, file2: num_nonblank2, ... },
##    { col_hdr2: { file1: num_nonblank1, file2: num_nonblank2, ... }
##    ... , { col_hdrn: { file1: num_nonblank1, file2: num_nonblank2, ... } }
def get_number_nonblank(file_list):
    num_nonblank = {}
    columns = get_columns(file_list)
    for col in columns:
        file_dict = {}
        for file in file_list:
            with open(file, encoding="cp437") as csv_file:
                csv_reader = csv.reader(csv_file)
                header = next(csv_reader)
                if col in header:
                    index = header.index(col)
                    num_non_blank = 0
                    for row in csv_reader:
                        if row[index] != "":
                            num_non_blank = num_non_blank + 1
                    file_dict[file] = num_non_blank
        num_nonblank[col] = file_dict
    return num_nonblank

## creates the CSV described in one of Dr. Tharsen's emails
## -- human-readable representation of number nonblank dictionary
def view_number_nonblank(file_list, file_name):
    num_nonblank = get_number_nonblank(file_list)
    f = open(file_name, "w", encoding="utf8")
    f.write(",")
    for file in file_list:
        f.write(file + ",")
    f.write("\n")
    for header in num_nonblank:
        f.write(header + ",")
        for file in file_list:
            if file in num_nonblank[header]: 
                f.write(str(num_nonblank[header][file]) + ",")
            else:
                f.write(",")
        f.write("\n")
    f.close()


###############################################################################

##                 Determining which layouts to use                          ##

###############################################################################

class MissingCols:
    def __init__(self, layout):
        self.layout = layout
        self.num_cols = 0
        self.missing_cols = set()

    def __lt__(self, other):
        return self.num_cols < other.num_cols

    def __eq__(self, other):
        return self.num_cols == other.num_cols

    def add_col(self, col):
        self.missing_cols.add(col)
        self.num_cols += 1


## get a dictionary of each file in the input list attached to a list of 
## columns for which that file does not have the maximal amount of data
## under that column
## helper function for get_best_layout and get_good_layouts
def get_bad_cols(file_list):
    cols = get_columns(file_list)
    num_cols = len(cols)
    num_nonblank = get_number_nonblank(file_list)
    bad_cols = {}
    for file in file_list:
        bad_cols[file] = MissingCols(file)
    for col in cols:
        assert col in num_nonblank
        max_nnb = 0
        for layout in num_nonblank[col]:
            if num_nonblank[col][layout] > max_nnb:
                max_nnb = num_nonblank[col][layout]
        if max_nnb > 0:
            for file in file_list:
                if file not in num_nonblank[col]:
                    bad_cols[file].add_col(col)
                else:
                    if num_nonblank[col][file] < max_nnb:
                        bad_cols[file].add_col(col)
    return bad_cols, cols


## Get layouts that contains at least as many nonempty cells under each column
## as every other file, for every column
## perfect_files: list of files which contain the max number nonblank in all the columns
def get_best_layout(file_list, verbose):
    bad_cols, cols = get_bad_cols(file_list)
    num_cols = len(cols)
    if verbose: 
        print(str(num_cols) + " total columns.")
    perfect_files = []
    for file in bad_cols:
        num_max = num_cols - bad_cols[file].num_cols
        if verbose:
            print(file + " has max in " + str(num_max) + " columns." )
        if num_max == num_cols:
            perfect_files.append(file)
    if verbose:
        print("perfect files:")
        for file in perfect_files:
            print("--" + file)
    return bad_cols, perfect_files


class GoodLayout:
    def __init__(self, layouts):
        self.layouts = []
        first = True
        for layout in layouts:
            self.layouts.append(layout.layout)
            if first:
                self.missing_cols = layout.missing_cols
                first = False
            else:
                self.missing_cols.intersection_update(layout.missing_cols)
        self.num_cols = len(self.missing_cols)
      

## find a minimal list of layouts that together contain all the data
## (assuming data under the same header in different layouts is the same if present)
def get_good_layouts(file_list, verbose):
    bad_cols, cols = get_bad_cols(file_list)
    num_cols = len(cols)
    if verbose:
        print("there are " + str(num_cols) + " columns total")
    
    missing_cols_list = []
    for key in bad_cols:
        missing_cols_list.append(bad_cols[key])
        missing_cols_list.sort()

    num_layouts = len(missing_cols_list)

    for k in range(num_layouts):
        combos = itertools.combinations(missing_cols_list, k+1)
        while True:
            try:
                layouts = combos.__next__()
                intersection = GoodLayout(layouts)
                if verbose:
                    print(str(intersection.num_cols) + " missing cols for intersection of:")
                    for file in intersection.layouts:
                        print("-- " + file)
                if intersection.num_cols == 0:
                    return intersection.layouts
            except StopIteration:
                break
            except:
                print("Unexpected error:", sys.exc_info()[0])
    return None

## layout that contains all the data for a given fmp export
## (assuming data under the same column is the same in different layouts
class PerfectLayout:
    def __init__(self, fmp_file, layouts):
        self.fmp_file = fmp_file
        self.layouts = layouts
        self.num_layouts = len(layouts)


## recursively finds perfect layouts for all sets of fmp files in a directory
## (see get_best_layout)
def find_perfect_layouts(rootdir):
    file_sets = get_fmp_exports(rootdir)
    perfect_layouts = []
    num_sets = 0
    for fmp_set in file_sets:
        num_sets += 1
        bad_rows, perfect_files = get_best_layout(fmp_set.layouts, False)
        num_perf = len(perfect_files)
        if num_perf > 0:
            pl = PerfectLayout(fmp_set.fmp_file, perfect_files)
            perfect_layouts.append(pl)
    num_with_perf = len(perfect_layouts)
    print(str(num_with_perf) + " of " + str(num_sets) + " have perf")
    return perfect_layouts


## recursively finds good layouts from a directory (see get_good_layouts)
def find_good_layouts(rootdir):
    file_sets = get_fmp_exports(rootdir)
    good_layouts = []
    bad_sets = []
    num_sets = 0
    for fmp_set in file_sets:
        num_sets += 1
        good_files = get_good_layouts(fmp_set.layouts, False)
        if good_files:
            good_layouts.append(good_files)
        else:
            bad_sets.append(fmp_set)
    num_with_good = len(good_layouts)
    num_bad_sets = len(bad_sets)
    print(str(num_with_good) + " of " + str(num_sets) + " have perf")
    print(str(num_bad_sets) + " bad sets")
    return good_layouts, bad_sets



###############################################################################

##    Check whether within a set, data under a particular column matches     ##

###############################################################################

## contains data for a column in a particular file
class Column:
    def __init__(self, file, header, data):
        self.file = file
        self.header = header
        self.data = data

## go through dictionary and check whether the files 
## that have the same header have the same data under
## that header
def have_different_data(file_list):
    files_with_header = get_files_with_header(file_list)
    diff_data = {}
    for col in files_with_header:
        diff_data[col] = []
        saved_rows = []
        for file in files_with_header[col]:
            with open(file, encoding="cp437") as csv_file:
                csv_reader = csv.reader(csv_file)
                header = next(csv_reader)
                index = header.index(col)

                row_array = []
                for row in csv_reader:
                    s = row[index]
                    ## fix encoding
                    s = ftfy.fix_text(s)
                    ## get rid of extra zeros 
                    try:
                        x = float(s)
                        if x.is_integer:
                            row_array.append(str(int(x)))
                        else:
                            row_array.append(s)
                    except ValueError:
                        row_array.append(s)
                
                ## skip if one of the columns is blank
                if row_array != [] and row_array not in saved_rows:
                    saved_rows.append(row_array)
                    new_col = Column(file,col,row_array)
                    diff_data[col].append(new_col)

    for col in files_with_header:
        if len(diff_data[col]) <= 1:
            del(diff_data[col])

    return diff_data

## creates a csv with files with different data under the 
## same column header side-by-side

## {col: {file, header, data}}

## header
## file1, file2, file3
## f1row1, f2row1, f3row1
## f1row2, f2row2, f3row2
## ...
## f1rown, f2rown, f3rown

def visual_compare(file_list, file_name):
    print("begin vc")
    dict_2 = have_different_data(file_list)
    print("dict_2 created")
    f = open(file_name, "w", encoding="utf8")
    print("file opened")
    for col in dict_2:
        print(col)
        f.write(col + "\n")
        print("col written")
        num_files = len(dict_2[col])
        print(num_files, "files")
        arr_len = len(dict_2[col][0].data)
        for file in dict_2[col]: 
            if len(file.data) != arr_len:
                f.write("arrays have different length\n")
                print("arrays have different lenght")
                for file in dict_2[col]:
                    f.write(file.file + ",")
                f.write("/n")
                while True:
                    for file in dict_2[col]:
                        if file.data != []:
                            f.write(file.data[0])
                            file.data.remove(file.data[0])
                        else: 
                            f.write("EMPTY,")
                    f.write("\n")
                    all_empty = True
                    for file in dict_2[col]:
                        if file.data != []:
                            all_empty = False
                    if all_empty:
                        f.close()
                        break
                return
        for file in dict_2[col]: 
            print(file.file)
            f.write(file.file + ",")
        f.write("row has different data?\n")    
        for i in range(0,arr_len):
            row_set = set()
            for file in dict_2[col]:
                f.write(file.data[i] + ",")
                row_set.add(file.data[i])
            if len(row_set) > 1:
                f.write("YES\n")
            else:
                f.write("NO\n")
    f.close()


## find a set with non-mathcing data to compare in a directory, if one exists
def compare_files(rootdir):
    fmp_sets = get_fmp_exports(rootdir)
    num_zero = 0
    for f in fmp_sets:
        print(num_zero)
        diff_data = have_different_data(f.layouts)
        num_diff = len(diff_data)
        if num_diff == 0: 
            print("no diff")
            num_zero += 1
        else: 
            print("before vc")
            visual_compare(f.layouts, "vc.csv")
            return next (iter (diff_data.values()))
    return num_zero



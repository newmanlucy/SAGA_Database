Contact:
Lucy Newman
newmanlucy@uchicago.edu

Cho Yin Kong
kongc@uchicago.edu

===============================================================================

Contents of this zip file:

- README.md (the current file): contact info, instructions, known issues
- fmp_to_excel.fp7
- excel_to_csv.xlsm
- inspect_csv.py
- test_files: contains sample CSV exports for quick testing with Python

===============================================================================

Instructions for converting an FMP coding file to CSVs that can be added to 
the database:

1.  FileMaker Pro to Excel. Each FileMaker file must be converted individually.
    Create a new script called Export in the FMP file being converted. Open 
    fmp_to_excel.fp7, and open the macro Export for editing. Select and copy 
    the contents of this macro to the new script in the file being converted. 
    Save and run the script.

2.  Excel to CSV. Create and label a directory on a Windows computer in which 
    you will do the conversions. Move the directory containing the Excel files 
    to be converted to this folder. 

    The file excel_to_csv.xlsm should be in the same directory as
    folders containing the Excel files being converted (the program recursively 
    searches the entire directory). Open excel_to_csv.xlsm. Run the macro 
    ExportToCSV. Once everything has been converted, you should get the 
    notification 'Done' in a message box. 

    Move the files back to the server. The computer should ask you whether you
    want to skip files with the same name, and you should say yes. This way it
    only moves the CSVs and doesn't replace the Excel files and other files.

    I was not able to run this script over the server. This can be tried, but 
    there seemed to be an issue with opening the Excel files over the server
    from my laptop.

3.  Getting information from the CSVs. The most important functions in
    inspect_csv.py are find_good_layouts and have_different_data.
    find_good_layouts takes a root directory and finds sets CSV files 
    resulting from a single FileMaker Pro export, and then determines a minimal
    set of files necessary to provide all the data, given that data under a
    given header is the same in different layouts. have_different_data
    determines whether this assumption is accurate. Other functions in 
    inspect_csv.py allow for further analysis of the files and are described in
    the comments.

    This code was written on a Windows computer, so some slight modifications
    would be necessary for non-Windows operating systems. This includes file
    encodings (ANSI on Windows should be changed to cp437 on Linux) and file 
    paths. 

    Additionally, we assume that the FileMaker Pro files which were used to
    produce these CSVs are still in the same directory, and that these
    instructions have been followed, to produce the CSVs. We separate the CSVs
    based on files within a given subdirectory whose name contains a FMP file's
    name as a substring.

===============================================================================

Known issues:

- The Excel macro breaks because of an apparently missing file in the United
States directory. More error checking should be added for this.

- Some sets of CSVs resulting from a single FileMaker export still have 
different data under the same column header. Further investigation is needed
to uncover why this might be. The function visual_compare in this file may be
useful in figuring out why this is. Additionally, one could try vimdiff or
other text comparison programs. 

- If there are sets of CSVs which have two files with legitimately different 
data under the same header (rather than just encoding errors or decimal 
approximations, etc.) then we will need another approach to determinine which
files to export, other than the current find_good_layouts.
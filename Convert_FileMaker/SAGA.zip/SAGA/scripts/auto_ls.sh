#!/usr/bin/env bash

## To run this function, from the command-prompt, type:
##  sh auto_ls.sh [list_file]

echo "Here we go";

## Set filename to list_file
filename="$1"

while read -r line
do
    name="$line"

## Strip to filename only
    target=$(basename "$name"); 

	##transform spaces in target to underscores
##	target=${target// /_}

    echo "File: $target"

## Do ls to check if file name and path are valid
    ls "$name"; 

done < "$filename"

set = set()

s1 = "tape	true link	utt #	within utt sign seq	within v sign seq	xP3]orig vignette order	xP3]subj condition abb	xP3]subjses	aa represents	active artic	begin pt	Check Link	confidence gesture	confidence meaning	corrected at	end pt	Error	form gloss	ge/sp relationship	gesture comment	gesture description	held through	justification of revised prop	link	meaning gloss	meaning of plus	meaning source	place equals ba	place represents	place type	prop type	recheck	Recheck Comments	relationship of ch to ve	rep by hs	repair of	rev prop type	sign time	sign type	size	syntactic function	TC Display	Temp Text	transcript number	VTR Running	with held sign"

s2 = "articulator	comments	deleted	description	first 33 min	link to next	meaning source	referent	repeat number	repetition same/diff	session	sign number	sign tploc	signer/speaker	subject	syntactic function	syntax utt number	tploc	type	uttplussign"

s3 = "syntax utt number	sign number	referent	meaning source	type	syntactic function	description	code morph	sign tploc	utt tploc	uttplussign"

s4 = "syntax utt number	sign number	referent	meaning source	type	syntactic function	description	code morph	sign tploc	utt tploc	uttplussign	articulator	comments	first 33 min	link to next	repeat number	repetition same/diff	session	signer/speaker	subject	tploc"

hdr_array = [s1,s2,s3,s4]

for hdr in hdr_array:
	arr = hdr.split("\t")

	num_added = len(arr)
	print "len to be added: " + str(num_added)
	set_len = len(set)

	for col in arr:
		set.add(col)
	new_set_len = len(set)
	print "number of overlaps: " + str(set_len + num_added - new_set_len)

print "final length: " + str(len(set))
